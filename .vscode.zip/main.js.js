// scroll suavisado
$(document).ready(function(){
    console.log("hola mundo");
});